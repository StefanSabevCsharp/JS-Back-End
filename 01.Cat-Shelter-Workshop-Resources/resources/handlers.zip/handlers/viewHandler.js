
const {homeView} = require("./homeView");

module.exports = [homeView];